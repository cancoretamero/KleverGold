// Clave pública (quedará visible si publicas el sitio)
window.METALS_API_KEY = "0zs12hfbt7uf6jf5brv7xpq8o8175lpnwmpamvqkoz238mjqjyxxhdji4fb4";
